#include <cstdio>

int main() {
	for(long long i = 0; i<100000000000LL;i++);
}