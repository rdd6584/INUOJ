#include <cstdio>

int main() {
	int n,m,k;
	scanf("%d %d %d",&n,&m,&k);
	long long cnt = 0;
	for(long long i = 0; i<100000000000LL;i++) cnt++;
	printf("%lld", cnt);
		
}